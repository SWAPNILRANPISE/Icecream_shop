Ice Cream Shop Spring Boot project (full)
-----------------------------------------
What is included:
- Spring Boot app with Thymeleaf frontend.
- User registration, login (Spring Security), role-based admin.
- Admin panel to add flavors/containers and promote users.
- DataLoader will create sample flavors, containers, and two users on startup:
    * admin / admin (role ADMIN)
    * user  / user  (role USER)

How to run:
1. Install Java 17 and Maven.
2. Start MySQL and update src/main/resources/application.properties with your DB username/password.
3. From project root, run: mvn spring-boot:run
4. Open http://localhost:9090/

Notes:
- Passwords use BCrypt. Default admin credentials: admin / admin
