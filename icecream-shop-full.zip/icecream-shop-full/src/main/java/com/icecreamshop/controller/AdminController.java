package com.icecreamshop.controller;

import com.icecreamshop.model.Flavor;
import com.icecreamshop.model.Container;
import com.icecreamshop.model.User;
import com.icecreamshop.repository.FlavorRepository;
import com.icecreamshop.repository.ContainerRepository;
import com.icecreamshop.repository.UserRepository;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin")
public class AdminController {
    private final FlavorRepository flavorRepo;
    private final ContainerRepository containerRepo;
    private final UserRepository userRepo;
    private final BCryptPasswordEncoder encoder;

    public AdminController(FlavorRepository flavorRepo, ContainerRepository containerRepo, UserRepository userRepo, BCryptPasswordEncoder encoder) {
        this.flavorRepo = flavorRepo;
        this.containerRepo = containerRepo;
        this.userRepo = userRepo;
        this.encoder = encoder;
    }

    @GetMapping
    public String adminHome(Model model) {
        model.addAttribute("flavors", flavorRepo.findAll());
        model.addAttribute("containers", containerRepo.findAll());
        model.addAttribute("users", userRepo.findAll());
        return "admin";
    }

    @PostMapping("/flavor")
    public String addFlavor(@RequestParam String name, @RequestParam double price) {
        Flavor f = new Flavor();
        f.setName(name);
        f.setPrice(price);
        flavorRepo.save(f);
        return "redirect:/admin";
    }

    @PostMapping("/container")
    public String addContainer(@RequestParam String type, @RequestParam double price) {
        Container c = new Container();
        c.setType(type);
        c.setPrice(price);
        containerRepo.save(c);
        return "redirect:/admin";
    }

    @PostMapping("/make-admin")
    public String makeAdmin(@RequestParam Integer userId) {
        User u = userRepo.findById(userId).orElse(null);
        if (u != null) {
            u.setRole("ADMIN");
            userRepo.save(u);
        }
        return "redirect:/admin";
    }
}
