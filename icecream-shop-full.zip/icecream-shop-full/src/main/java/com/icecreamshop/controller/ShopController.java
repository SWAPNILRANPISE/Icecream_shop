package com.icecreamshop.controller;

import com.icecreamshop.model.Flavor;
import com.icecreamshop.model.Container;
import com.icecreamshop.model.Order;
import com.icecreamshop.repository.FlavorRepository;
import com.icecreamshop.repository.ContainerRepository;
import com.icecreamshop.repository.OrderRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class ShopController {
    private final FlavorRepository flavorRepo;
    private final ContainerRepository containerRepo;
    private final OrderRepository orderRepo;

    public ShopController(FlavorRepository flavorRepo, ContainerRepository containerRepo, OrderRepository orderRepo) {
        this.flavorRepo = flavorRepo;
        this.containerRepo = containerRepo;
        this.orderRepo = orderRepo;
    }

    @GetMapping({"/", "/home"})
    public String home(Model model) {
        List<Flavor> flavors = flavorRepo.findAll();
        List<Container> containers = containerRepo.findAll();
        model.addAttribute("flavors", flavors);
        model.addAttribute("containers", containers);
        return "index";
    }

    @PostMapping("/order")
    public String placeOrder(@RequestParam String customerName,
                             @RequestParam Integer flavorId,
                             @RequestParam Integer containerId,
                             Model model) {
        Flavor f = flavorRepo.findById(flavorId).orElse(null);
        Container c = containerRepo.findById(containerId).orElse(null);
        if (f == null || c == null) {
            model.addAttribute("error", "Invalid selection");
            return "index";
        }
        Order o = new Order();
        o.setCustomerName(customerName);
        o.setFlavor(f);
        o.setContainer(c);
        o.setTotalPrice(f.getPrice() + c.getPrice());
        orderRepo.save(o);
        model.addAttribute("success", "Order placed! Total: " + o.getTotalPrice());
        return "redirect:/";
    }
}
