package com.icecreamshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IcecreamShopApplication {
    public static void main(String[] args) {
        SpringApplication.run(IcecreamShopApplication.class, args);
    }
}
