package com.icecreamshop.config;

import com.icecreamshop.model.Container;
import com.icecreamshop.model.Flavor;
import com.icecreamshop.model.User;
import com.icecreamshop.repository.ContainerRepository;
import com.icecreamshop.repository.FlavorRepository;
import com.icecreamshop.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@Configuration
public class DataLoader {

    @Bean
    CommandLineRunner loadData(FlavorRepository flavorRepo, ContainerRepository containerRepo, UserRepository userRepo, BCryptPasswordEncoder encoder) {
        return args -> {
            if (flavorRepo.count() == 0) {
                Flavor f1 = new Flavor(); f1.setName("Vanilla"); f1.setPrice(40.0); flavorRepo.save(f1);
                Flavor f2 = new Flavor(); f2.setName("Chocolate"); f2.setPrice(50.0); flavorRepo.save(f2);
                Flavor f3 = new Flavor(); f3.setName("Strawberry"); f3.setPrice(45.0); flavorRepo.save(f3);
            }

            if (containerRepo.count() == 0) {
                Container c1 = new Container(); c1.setType("Cup"); c1.setPrice(10.0); containerRepo.save(c1);
                Container c2 = new Container(); c2.setType("Cone"); c2.setPrice(15.0); containerRepo.save(c2);
            }

            if (userRepo.findByUsername("admin") == null) {
                User admin = new User();
                admin.setUsername("admin");
                admin.setPassword(encoder.encode("admin")); // default password: admin
                admin.setRole("ADMIN");
                userRepo.save(admin);
            }
            if (userRepo.findByUsername("user") == null) {
                User u = new User();
                u.setUsername("user");
                u.setPassword(encoder.encode("user")); // default password: user
                u.setRole("USER");
                userRepo.save(u);
            }
        };
    }
}
