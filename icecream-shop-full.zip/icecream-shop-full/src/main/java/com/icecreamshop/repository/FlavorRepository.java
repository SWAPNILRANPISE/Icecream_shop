package com.icecreamshop.repository;

import com.icecreamshop.model.Flavor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FlavorRepository extends JpaRepository<Flavor, Integer> {
}
