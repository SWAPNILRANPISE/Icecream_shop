package com.icecreamshop.model;

import jakarta.persistence.*;

@Entity
@Table(name="orders")
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String customerName;

    @ManyToOne
    private Flavor flavor;

    @ManyToOne
    private Container container;

    private double totalPrice;

    public Order() {}
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }
    public Flavor getFlavor() { return flavor; }
    public void setFlavor(Flavor flavor) { this.flavor = flavor; }
    public Container getContainer() { return container; }
    public void setContainer(Container container) { this.container = container; }
    public double getTotalPrice() { return totalPrice; }
    public void setTotalPrice(double totalPrice) { this.totalPrice = totalPrice; }
}
